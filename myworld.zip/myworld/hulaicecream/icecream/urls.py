from django.urls import path
from . import views
urlpatterns = [ 
    path('icecream/', views.icecream, name='icecream'),
]