import random 

#Let the computer chose a combination of 4 colours
colors = ["Black","White", "Red", "Yellow", "Blue", "Green"]
computercolor1 = random.choice(colors)
computercolor2 = random.choice(colors)
computercolor3 = random.choice(colors)
computercolor4 = random.choice(colors)

for i in range (1,11):
    userColor1 = input('Color 1?')
    userColor2 = input('Color 2?')
    userColor3 = input('Color 3?')
    userColor4 = input('Color 4?')
    
    pegsInRightPosition = 0
    pegsMisplaced = 0
    if userColor1 == computercolor1:
        pegsInRightPosition+=1
    else:
        if userColor1==computercolor2 or userColor1==computercolor3 or userColor1 ==computercolor4:
            pegsMisplaced+=1
    if userColor2==computercolor2:
        pegsInRightPosition +=1
    else:
        if userColor2==computercolor1 or userColor2==computercolor3 or userColor2==computercolor4:
            pegsMisplaced+=1
    if userColor3==computercolor3:
        pegsInRightPosition+=1
    else:
        if userColor3==computercolor1 or userColor3==computercolor2 or userColor3==computercolor4:
            pegsMisplaced+=1
    if userColor4 == computercolor4:
        pegsInRightPosition+=1
    else:
        if userColor4==computercolor1 or userColor4==computercolor2 or userColor3==computercolor3:
            pegsMisplaced+=1
    #Output results to the user
    print("Correct pegs:" + str(pegsInRightPosition))
    print("Misplaced pegs:" + str(pegsMisplaced))
    #All pegs right?
    if pegsInRightPosition ==4:
        break
    #Final output
    if pegsInRightPosition==4:
        print("***You Win****")
    else:
        print("***Game over*****")

